# Instituto Educacional Dominique - Site Completo

## 🚀 Instalação Rápida

### 1. Instalar Dependências
```bash
npm install
```

### 2. Configurar Banco de Dados
```bash
npm run db:push
```

### 3. Iniciar o Servidor
```bash
npm run dev
```

O site estará disponível em: http://localhost:3000

## 📁 Estrutura do Projeto

- `src/` - Código fonte do site
- `public/` - Arquivos estáticos (imagens, logos)
- `prisma/` - Configuração do banco de dados
- `db/` - Banco de dados SQLite com dados
- `server.ts` - Servidor customizado com Socket.IO

## 🔐 Credenciais Padrão

- **Admin**: admin@dominique.com / admin123
- **Professor**: teacher@dominique.com / teacher123  
- **Aluno**: student@dominique.com / student123

## 📱 Funcionalidades

- ✅ Site institucional completo
- ✅ Sistema de login para diferentes perfis
- ✅ Formulário de contato funcional
- ✅ Navegação suave entre seções
- ✅ Design responsivo
- ✅ Carousel automático de imagens
- ✅ Sistema de gestão educacional

## 🌐 Acesso

- **Site Principal**: http://localhost:3000
- **Portal de Acesso**: http://localhost:3000/login
- **Admin**: http://localhost:3000/admin
- **Professor**: http://localhost:3000/teacher
- **Aluno**: http://localhost:3000/student

## 📞 Suporte

Para dúvidas ou suporte técnico, consulte a documentação ou entre em contato.
