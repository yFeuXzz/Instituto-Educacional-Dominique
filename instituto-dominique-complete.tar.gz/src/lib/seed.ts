import { db } from '@/lib/db'
import bcrypt from 'bcryptjs'

async function seedUsers() {
  try {
    // Criar usuário admin
    const hashedAdminPassword = await bcrypt.hash('admin123', 12)
    const admin = await db.user.upsert({
      where: { email: 'admin@dominique.com' },
      update: { password: hashedAdminPassword },
      create: {
        email: 'admin@dominique.com',
        name: 'Administrador',
        password: hashedAdminPassword,
        role: 'ADMIN'
      }
    })

    // Criar usuário estudante
    const hashedStudentPassword = await bcrypt.hash('aluno123', 12)
    const student = await db.student.upsert({
      where: { email: 'joao.silva@dominique.com' },
      update: { password: hashedStudentPassword },
      create: {
        name: 'João Silva',
        email: 'joao.silva@dominique.com',
        phone: '(11) 98765-4321',
        address: 'Rua das Flores, 123',
        birthDate: '2010-05-15',
        grade: '8ano',
        enrollment: '2024001',
        password: hashedStudentPassword
      }
    })

    // Criar usuário professor
    const hashedTeacherPassword = await bcrypt.hash('professor123', 12)
    const teacherUser = await db.user.upsert({
      where: { email: 'maria.silva@dominique.com' },
      update: { password: hashedTeacherPassword },
      create: {
        email: 'maria.silva@dominique.com',
        name: 'Maria Silva',
        password: hashedTeacherPassword,
        role: 'TEACHER'
      }
    })

    const teacher = await db.teacher.upsert({
      where: { email: 'maria.silva@dominique.com' },
      update: { password: hashedTeacherPassword },
      create: {
        userId: teacherUser.id,
        name: 'Maria Silva',
        email: 'maria.silva@dominique.com',
        phone: '(11) 91234-5678',
        subjects: '["matematica", "portugues"]',
        grades: '["6ano", "7ano", "8ano", "9ano"]',
        password: hashedTeacherPassword
      }
    })

    console.log('Teacher criado:', teacher)
    console.log('Password do teacher:', teacher.password)

    console.log('Usuários criados com sucesso:')
    console.log('Admin:', admin.email)
    console.log('Student:', student.email)
    console.log('Teacher:', teacher.email)

  } catch (error) {
    console.error('Erro ao criar usuários:', error)
  } finally {
    await db.$disconnect()
  }
}

seedUsers()