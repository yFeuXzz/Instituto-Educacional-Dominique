import { NextAuthOptions } from 'next-auth'
import CredentialsProvider from 'next-auth/providers/credentials'
import { db } from '@/lib/db'
import bcrypt from 'bcryptjs'

console.log('🔧 AUTH TS: Module loaded')

export const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      name: 'credentials',
      credentials: {
        email: { label: 'Email', type: 'email' },
        password: { label: 'Senha', type: 'password' }
      },
      async authorize(credentials) {
        console.log('🔐 AUTH CALLED FOR:', credentials?.email)
        console.log('🔐 AUTH FULL CREDENTIALS:', credentials)
        console.log('🔐 NEXTAUTH_SECRET exists:', !!process.env.NEXTAUTH_SECRET)
        
        if (!credentials?.email || !credentials?.password) {
          console.log('❌ MISSING CREDENTIALS')
          return null
        }

        try {
          console.log('🔍 AUTH: Searching for user...')
          const user = await db.user.findUnique({
            where: { email: credentials.email }
          })

          console.log('👤 USER FOUND:', user?.email, user?.role, user?.id)

          if (!user || !user.password) {
            console.log('❌ NO USER OR PASSWORD')
            return null
          }

          console.log('🔑 AUTH: Comparing passwords...')
          console.log('🔑 Input password:', credentials.password)
          console.log('🔑 Hashed password:', user.password.substring(0, 20) + '...')
          
          const isPasswordValid = await bcrypt.compare(
            credentials.password,
            user.password
          )

          console.log('🔑 PASSWORD VALID:', isPasswordValid)

          if (!isPasswordValid) {
            console.log('❌ INVALID PASSWORD')
            return null
          }

          console.log('✅ LOGIN SUCCESS:', credentials.email, 'ROLE:', user.role)
          
          const result = {
            id: user.id,
            email: user.email,
            name: user.name,
            role: user.role
          }
          
          console.log('✅ AUTH RETURNING:', result)
          return result
        } catch (error) {
          console.error('💥 AUTH ERROR:', error)
          return null
        }
      }
    })
  ],
  session: { strategy: 'jwt' },
  secret: process.env.NEXTAUTH_SECRET,
  callbacks: {
    async jwt({ token, user }) {
      console.log('🔐 JWT CALLBACK - Token:', token)
      console.log('🔐 JWT CALLBACK - User:', user)
      
      if (user) {
        token.role = user.role
        token.id = user.id
        console.log('🔐 JWT CALLBACK - Updated token:', token)
      }
      return token
    },
    async session({ session, token }) {
      console.log('🔐 SESSION CALLBACK - Session:', session)
      console.log('🔐 SESSION CALLBACK - Token:', token)
      
      if (token) {
        session.user.id = token.id as string
        session.user.role = token.role as string
        console.log('🔐 SESSION CALLBACK - Updated session:', session)
      }
      return session
    }
  },
  pages: {
    signIn: '/login'
  },
  debug: true
}

console.log('🔧 AUTH TS: Options configured')