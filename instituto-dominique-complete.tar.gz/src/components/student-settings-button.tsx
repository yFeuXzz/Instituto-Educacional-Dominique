'use client'

import { User } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'
import Link from 'next/link'

export function StudentSettingsButton() {
  return (
    <TooltipProvider>
      <div className="fixed top-4 right-4 z-50">
        <Tooltip>
          <TooltipTrigger asChild>
            <Link href="/student/settings">
              <Button
                variant="outline"
                size="sm"
                className={`
                  group relative rounded-full w-12 h-12 p-0 shadow-lg
                  bg-background/90 backdrop-blur-sm border-2 border-green-200
                  hover:bg-green-50 hover:border-green-300 hover:shadow-xl
                  transition-all duration-300 ease-in-out
                  hover:scale-110 hover:rotate-90
                `}
              >
                <User 
                  className={`
                    w-5 h-5 text-green-600
                    transition-all duration-300
                    group-hover:text-green-700 group-hover:scale-110
                  `} 
                />
                <div className="absolute inset-0 rounded-full bg-green-100 animate-pulse opacity-50"></div>
              </Button>
            </Link>
          </TooltipTrigger>
          <TooltipContent side="left">
            <p>Meus Dados</p>
          </TooltipContent>
        </Tooltip>
      </div>
    </TooltipProvider>
  )
}