import { withAuth } from 'next-auth/middleware'
import { NextResponse } from 'next/server'

export default withAuth(
  function middleware(req) {
    console.log('🔍 MIDDLEWARE: Path:', req.nextUrl.pathname)
    console.log('🔍 MIDDLEWARE: Token:', req.nextauth.token)
    
    const token = req.nextauth.token
    const isAdmin = token?.role === 'ADMIN'
    const isTeacher = token?.role === 'TEACHER'
    const isStudent = token?.role === 'STUDENT'
    
    const { pathname } = req.nextUrl

    console.log('🔍 MIDDLEWARE: Roles:', { isAdmin, isTeacher, isStudent })

    // Permitir acesso às rotas públicas
    if (
      pathname === '/' ||
      pathname === '/login' ||
      pathname === '/register' ||
      pathname === '/debug-auth' ||
      pathname.startsWith('/api/auth') ||
      pathname.startsWith('/_next') ||
      pathname.startsWith('/favicon') ||
      pathname.startsWith('/debug-grades') ||
      pathname.startsWith('/logo') ||
      pathname.endsWith('.jpg') ||
      pathname.endsWith('.png') ||
      pathname.endsWith('.svg') ||
      pathname.endsWith('.ico')
    ) {
      console.log('🔍 MIDDLEWARE: Public path allowed')
      return NextResponse.next()
    }

    // Proteger rotas de admin
    if (pathname.startsWith('/admin') && !isAdmin) {
      console.log('🔍 MIDDLEWARE: Admin access denied, redirecting to login')
      return NextResponse.redirect(new URL('/login', req.url))
    }

    // Proteger rotas de professor
    if (pathname.startsWith('/teacher') && !isTeacher) {
      console.log('🔍 MIDDLEWARE: Teacher access denied, redirecting to login')
      return NextResponse.redirect(new URL('/login', req.url))
    }

    // Proteger rotas de estudante
    if (pathname.startsWith('/student') && !isStudent) {
      console.log('🔍 MIDDLEWARE: Student access denied, redirecting to login')
      return NextResponse.redirect(new URL('/login', req.url))
    }

    // Redirecionar usuários logados para o dashboard correto
    if (pathname === '/login' && token) {
      console.log('🔍 MIDDLEWARE: Logged in user accessing login, redirecting')
      if (isAdmin) {
        return NextResponse.redirect(new URL('/admin', req.url))
      } else if (isTeacher) {
        return NextResponse.redirect(new URL('/teacher', req.url))
      } else if (isStudent) {
        return NextResponse.redirect(new URL('/student', req.url))
      }
    }

    console.log('🔍 MIDDLEWARE: Access granted')
    return NextResponse.next()
  },
  {
    callbacks: {
      authorized: ({ token, req }) => {
        const { pathname } = req.nextUrl
        
        console.log('🔍 AUTHORIZED CALLBACK: Path:', pathname, 'Token:', !!token)
        
        // Permitir acesso às rotas públicas
        if (
          pathname === '/' ||
          pathname === '/login' ||
          pathname === '/register' ||
          pathname === '/debug-auth' ||
          pathname.startsWith('/api/auth') ||
          pathname.startsWith('/_next') ||
          pathname.startsWith('/favicon') ||
          pathname.startsWith('/debug-grades') ||
          pathname.startsWith('/logo') ||
          pathname.endsWith('.jpg') ||
          pathname.endsWith('.png') ||
          pathname.endsWith('.svg') ||
          pathname.endsWith('.ico')
        ) {
          console.log('🔍 AUTHORIZED CALLBACK: Public path allowed')
          return true
        }

        // Exigir autenticação para outras rotas
        const hasToken = !!token
        console.log('🔍 AUTHORIZED CALLBACK: Token required:', hasToken)
        return hasToken
      },
    },
  }
)

export const config = {
  matcher: [
    '/((?!api|_next/static|_next/image|favicon.ico).*)',
  ],
}