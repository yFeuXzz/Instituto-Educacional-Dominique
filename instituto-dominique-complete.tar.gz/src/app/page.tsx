'use client'

import { useState, useEffect, useRef } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { MapPin, Phone, Mail, Clock, BookOpen, Users, Award, Building, CheckCircle, ChevronLeft, ChevronRight, Calendar, Menu, X } from 'lucide-react'

// Hook para animação de fade-in ao rolar
function useFadeIn() {
  const [visibleElements, setVisibleElements] = useState<Set<string>>(new Set(['home'])) // Hero section starts visible
  const observerRef = useRef<IntersectionObserver | null>(null)

  useEffect(() => {
    const checkInitialVisibility = () => {
      const elements = document.querySelectorAll('.fade-in-section')
      elements.forEach((el) => {
        const rect = el.getBoundingClientRect()
        const isVisible = rect.top < window.innerHeight && rect.bottom > 0
        if (isVisible && el.id) {
          setVisibleElements((prev) => new Set(prev).add(el.id))
        }
      })
    }

    observerRef.current = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setVisibleElements((prev) => new Set(prev).add(entry.target.id))
          }
        })
      },
      {
        threshold: 0.1,
        rootMargin: '0px 0px -100px 0px'
      }
    )

    // Verificar visibilidade inicial após um pequeno delay
    const timeoutId = setTimeout(checkInitialVisibility, 100)

    // Observar mudanças
    const elements = document.querySelectorAll('.fade-in-section')
    elements.forEach((el) => observerRef.current?.observe(el))

    // Também verificar quando hash muda (navegação por âncora)
    const handleHashChange = () => {
      setTimeout(checkInitialVisibility, 100)
    }
    window.addEventListener('hashchange', handleHashChange)

    // Verificar também quando clica em links internos
    const handleClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement
      const link = target.closest('a')
      if (link && link.hash) {
        setTimeout(checkInitialVisibility, 300)
      }
    }
    document.addEventListener('click', handleClick)

    return () => {
      clearTimeout(timeoutId)
      elements.forEach((el) => observerRef.current?.unobserve(el))
      window.removeEventListener('hashchange', handleHashChange)
      document.removeEventListener('click', handleClick)
    }
  }, [])

  return visibleElements
}

export default function InstitutoDominique() {
  const [currentImage, setCurrentImage] = useState(0)
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  })
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle')
  const [submitMessage, setSubmitMessage] = useState('')

  // Carousel controls
  const nextImage = () => {
    setCurrentImage((prev) => (prev + 1) % 4)
  }

  const prevImage = () => {
    setCurrentImage((prev) => (prev - 1 + 4) % 4)
  }

  // Auto-play carousel
  useEffect(() => {
    const interval = setInterval(() => {
      nextImage()
    }, 5000) // Change image every 5 seconds

    return () => clearInterval(interval)
  }, [])
  
  const visibleElements = useFadeIn()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setSubmitStatus('idle')
    setSubmitMessage('')

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      })

      const data = await response.json()

      if (response.ok) {
        setSubmitStatus('success')
        setSubmitMessage(data.message || 'Mensagem enviada com sucesso! Entraremos em contato em breve.')
        setFormData({ name: '', email: '', phone: '', message: '' })
        
        // Limpar mensagem de sucesso após 5 segundos
        setTimeout(() => {
          setSubmitStatus('idle')
          setSubmitMessage('')
        }, 5000)
      } else {
        setSubmitStatus('error')
        setSubmitMessage(data.error || 'Erro ao enviar mensagem. Tente novamente.')
      }
    } catch (error) {
      setSubmitStatus('error')
      setSubmitMessage('Erro de conexão. Verifique sua internet e tente novamente.')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto flex items-center justify-between px-6 py-4">
          <div className="flex items-center space-x-4">
            <img 
              src="https://z-cdn-media.chatglm.cn/files/f7d4bb0e-17a3-4900-9972-f0a038b4fd94_images.jpg?auth_key=1792626539-82748de9c37142ac885c0fa5ee6e8b86-0-332b3bb888664b4dcb51abf406e5c9f6" 
              alt="Instituto Dominique Logo" 
              className="h-12 w-auto object-contain"
            />
            <div>
              <h1 className="text-xl font-bold text-blue-900">Instituto Educacional Dominique</h1>
              <p className="text-blue-700 text-xs italic">"O estudo é a luz da vida"</p>
            </div>
          </div>
          <nav className="hidden md:flex items-center space-x-6">
            <a href="#home" className="text-blue-900 hover:text-blue-700 transition-colors">Início</a>
            <a href="#about" className="text-blue-900 hover:text-blue-700 transition-colors">Sobre Nós</a>
            <a href="#events" className="text-blue-900 hover:text-blue-700 transition-colors">Eventos</a>
            <a href="#facilities" className="text-blue-900 hover:text-blue-700 transition-colors">Instalações</a>
            <a href="#contact" className="text-blue-900 hover:text-blue-700 transition-colors">Contato</a>
            <div className="flex items-center space-x-3 ml-6">
              <Link href="/login">
                <Button variant="outline" size="sm" className="border-blue-900 text-blue-900 hover:bg-blue-50">
                  Portal de Acesso
                </Button>
              </Link>
              <Button size="sm" className="bg-blue-900 text-white hover:bg-blue-800">
                Matricule-se
              </Button>
            </div>
          </nav>
          <button 
            className="md:hidden p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? (
              <X className="h-6 w-6 text-blue-900" />
            ) : (
              <Menu className="h-6 w-6 text-blue-900" />
            )}
          </button>
        </div>
        
        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-200">
            <nav className="flex flex-col space-y-3 px-6 py-4">
              <a 
                href="#home" 
                className="text-blue-900 hover:text-blue-700 transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Início
              </a>
              <a 
                href="#about" 
                className="text-blue-900 hover:text-blue-700 transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Sobre Nós
              </a>
              <a 
                href="#events" 
                className="text-blue-900 hover:text-blue-700 transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Eventos
              </a>
              <a 
                href="#facilities" 
                className="text-blue-900 hover:text-blue-700 transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Instalações
              </a>
              <a 
                href="#contact" 
                className="text-blue-900 hover:text-blue-700 transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Contato
              </a>
              <div className="flex flex-col space-y-3 pt-3 border-t border-gray-200">
                <Link href="/login" onClick={() => setIsMenuOpen(false)}>
                  <Button variant="outline" size="sm" className="border-blue-900 text-blue-900 hover:bg-blue-50 w-full">
                    Portal de Acesso
                  </Button>
                </Link>
                <Button size="sm" className="bg-blue-900 text-white hover:bg-blue-800 w-full">
                  Matricule-se
                </Button>
              </div>
            </nav>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <section id="home" className="relative py-20 px-4 fade-in-section opacity-0 transition-all duration-1000 ease-out bg-gradient-to-br from-blue-50 to-white"
             style={{ 
               opacity: visibleElements.has('home') ? 1 : 0,
               transform: visibleElements.has('home') ? 'translateY(0)' : 'translateY(30px)'
             }}>
        <div className="container mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="mb-4 bg-blue-900 text-white">Desde 1989</Badge>
              <h2 className="text-4xl md:text-5xl font-bold text-blue-900 mb-6">
                Transformando Vidas Através da Educação
              </h2>
              <p className="text-xl text-blue-700 font-medium mb-4 italic">
                "O estudo é a luz da vida"
              </p>
              <p className="text-lg text-gray-600 mb-8">
                Oferecemos educação de qualidade com metodologia inovadora, 
                preparando alunos para os desafios do futuro com valores sólidos 
                e conhecimento transformador.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="clickable bg-blue-900 hover:bg-blue-800 text-white font-medium">
                  Conheça Nossa Escola
                </Button>
                <Button size="lg" variant="outline" className="clickable border-blue-900 text-blue-900 hover:bg-blue-50 font-medium">
                  Agende uma Visita
                </Button>
              </div>
              <div className="grid grid-cols-3 gap-4 mt-8">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-900">30+</div>
                  <div className="text-sm text-gray-600">Anos de Excelência</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-900">2000+</div>
                  <div className="text-sm text-gray-600">Alunos Formados</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-900">95%</div>
                  <div className="text-sm text-gray-600">Aprovação</div>
                </div>
              </div>
            </div>
            <div className="relative">
              {/* Image Carousel */}
              <div className="relative aspect-square rounded-2xl overflow-hidden shadow-xl">
                <div className="relative w-full h-full">
                  {currentImage === 0 && (
                    <div className="absolute inset-0">
                      <img 
                        src="https://z-cdn-media.chatglm.cn/files/f7d4bb0e-17a3-4900-9972-f0a038b4fd94_images.jpg?auth_key=1792626539-82748de9c37142ac885c0fa5ee6e8b86-0-332b3bb888664b4dcb51abf406e5c9f6" 
                        alt="Instituto Educacional Dominique Logo" 
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                        <div className="text-center text-white p-8">
                          <h3 className="text-2xl font-bold mb-2">Instituto Dominique</h3>
                          <p className="text-lg italic">"O estudo é a luz da vida"</p>
                          <p className="text-sm mt-2">Desde 1989</p>
                        </div>
                      </div>
                    </div>
                  )}
                  {currentImage === 1 && (
                    <div className="absolute inset-0">
                      <img 
                        src="https://z-cdn-media.chatglm.cn/files/07fc9b5d-1970-4e28-8107-e9924d4abd11_images.jpg?auth_key=1792626539-dff492d2db27487ea6fe098827bf6617-0-33aedd8c0b6ea6d4408d6f7fcd1f6bb5" 
                        alt="Salas de Aula Modernas" 
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-blue-900/80 to-transparent flex items-end justify-center">
                        <div className="text-center text-white p-8">
                          <h3 className="text-3xl font-bold mb-2">Educação de Qualidade</h3>
                          <p className="text-xl">Salas modernas e climatizadas</p>
                        </div>
                      </div>
                    </div>
                  )}
                  {currentImage === 2 && (
                    <div className="absolute inset-0">
                      <img 
                        src="https://z-cdn-media.chatglm.cn/files/0b3bb972-2f7b-4f13-a396-61eb51af2e26_pasted_image_1760394848523.png?auth_key=1792626539-e3dd0e8fc95d41639e25092914df503e-0-e2a51d2227135405c2836df4fca8050" 
                        alt="Biblioteca" 
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-blue-900/80 to-transparent flex items-end justify-center">
                        <div className="text-center text-white p-8">
                          <h3 className="text-3xl font-bold mb-2">Comunidade Ativa</h3>
                          <p className="text-xl">Mais de 2000 alunos formados</p>
                        </div>
                      </div>
                    </div>
                  )}
                  {currentImage === 3 && (
                    <div className="absolute inset-0">
                      <img 
                        src="https://z-cdn-media.chatglm.cn/files/6bbc815a-996e-42b1-b98d-596ac9263523_images.jpg?auth_key=1792626539-c34ab09aa22840f1af4a037152886ab8-0-04eca8abd547bfcc7cd1190474c0221c" 
                        alt="Quadras Esportivas" 
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-blue-900/80 to-transparent flex items-end justify-center">
                        <div className="text-center text-white p-8">
                          <h3 className="text-3xl font-bold mb-2">Excelência</h3>
                          <p className="text-xl">95% de aprovação</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
                
                {/* Carousel Controls */}
                <button 
                  onClick={prevImage}
                  className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/20 backdrop-blur-sm text-white p-2 rounded-full hover:bg-white/30 transition-colors"
                >
                  <ChevronLeft className="w-6 h-6" />
                </button>
                <button 
                  onClick={nextImage}
                  className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/20 backdrop-blur-sm text-white p-2 rounded-full hover:bg-white/30 transition-colors"
                >
                  <ChevronRight className="w-6 h-6" />
                </button>
                
                {/* Carousel Indicators */}
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-2">
                  {[0, 1, 2, 3].map((index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentImage(index)}
                      className={`w-2 h-2 rounded-full transition-colors ${
                        currentImage === index ? 'bg-white' : 'bg-white/50'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-4 bg-blue-50 fade-in-section opacity-0 transition-all duration-1000 ease-out"
             style={{ 
               opacity: visibleElements.has('about') ? 1 : 0,
               transform: visibleElements.has('about') ? 'translateY(0)' : 'translateY(30px)'
             }}>
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">
              Sobre o Instituto Dominique
            </h2>
            <p className="text-xl text-blue-700 font-medium italic mb-4">
              "O estudo é a luz da vida"
            </p>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Há mais de 30 anos transformando a educação em João Pessoa com 
              excelência, compromisso e dedicação aos nossos alunos.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <Card className="card-clickable text-center fade-in-section opacity-0 transition-all duration-1000 ease-out delay-200 border-blue-200"
                  style={{ 
                    opacity: visibleElements.has('about') ? 1 : 0,
                    transform: visibleElements.has('about') ? 'translateY(0)' : 'translateY(30px)'
                  }}>
              <CardHeader>
                <div className="w-16 h-16 bg-blue-900 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-blue-900">Missão</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Promover educação de excelência, formando cidadãos críticos, 
                  conscientes e preparados para os desafios do século XXI, 
                  iluminando vidas através do conhecimento.
                </p>
              </CardContent>
            </Card>

            <Card className="card-clickable text-center fade-in-section opacity-0 transition-all duration-1000 ease-out delay-600 border-blue-200"
                  style={{ 
                    opacity: visibleElements.has('about') ? 1 : 0,
                    transform: visibleElements.has('about') ? 'translateY(0)' : 'translateY(30px)'
                  }}>
              <CardHeader>
                <div className="w-16 h-16 bg-blue-900 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-blue-900">Visão</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Ser referência em educação inovadora, reconhecida pela 
                  qualidade do ensino e pelo impacto positivo na comunidade,
                  sendo a luz que guia o futuro de nossos alunos.
                </p>
              </CardContent>
            </Card>

            <Card className="card-clickable text-center fade-in-section opacity-0 transition-all duration-1000 ease-out delay-600 border-blue-200"
                  style={{ 
                    opacity: visibleElements.has('about') ? 1 : 0,
                    transform: visibleElements.has('about') ? 'translateY(0)' : 'translateY(30px)'
                  }}>
              <CardHeader>
                <div className="w-16 h-16 bg-blue-900 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-blue-900">Valores</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Ética, respeito, inovação, compromisso, excelência e 
                  responsabilidade social. Acreditamos que o estudo 
                  verdadeiramente é a luz da vida.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Events Gallery */}
          <div className="mt-16">
            <h3 className="text-2xl font-bold text-blue-900 text-center mb-8">
              Nossos Eventos e Atividades
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                { id: 1, title: "Feira de Ciências", desc: "Mostra de projetos científicos", month: "Out", day: "15" },
                { id: 2, title: "Festa Junina", desc: "Tradições culturais brasileiras", month: "Jun", day: "10" },
                { id: 3, title: "Gincana Escolar", desc: "Competições e integração", month: "Set", day: "20" },
                { id: 4, title: "Semana Cultural", desc: "Apresentações artísticas", month: "Ago", day: "05" },
                { id: 5, title: "Formatura", desc: "Conclusão de mais um ciclo", month: "Dez", day: "18" },
                { id: 6, title: "Olimpíadas", desc: "Competições esportivas", month: "Mai", day: "25" }
              ].map((event, index) => (
                <div key={event.id} className="group bg-white rounded-lg shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden fade-in-section opacity-0"
                     style={{ 
                       opacity: visibleElements.has('about') ? 1 : 0,
                       transform: visibleElements.has('about') ? 'translateY(0)' : 'translateY(30px)',
                       transitionDelay: `${(index + 4) * 100}ms`
                     }}>
                  <div className="relative h-32">
                    <img 
                      src={
                        event.id === 1 ? "https://z-cdn-media.chatglm.cn/files/07fc9b5d-1970-4e28-8107-e9924d4abd11_images.jpg?auth_key=1792626539-dff492d2db27487ea6fe098827bf6617-0-33aedd8c0b6ea6d4408d6f7fcd1f6bb5" :
                        event.id === 2 ? "https://z-cdn-media.chatglm.cn/files/0b3bb972-2f7b-4f13-a396-61eb51af2e26_pasted_image_1760394848523.png?auth_key=1792626539-e3dd0e8fc95d41639e25092914df503e-0-e2a51d2227135405c2836df4fca8050" :
                        event.id === 3 ? "https://z-cdn-media.chatglm.cn/files/6bbc815a-996e-42b1-b98d-596ac9263523_images.jpg?auth_key=1792626539-c34ab09aa22840f1af4a037152886ab8-0-04eca8abd547bfcc7cd1190474c0221c" :
                        event.id === 4 ? "https://z-cdn-media.chatglm.cn/files/f7d4bb0e-17a3-4900-9972-f0a038b4fd94_images.jpg?auth_key=1792626539-82748de9c37142ac885c0fa5ee6e8b86-0-332b3bb888664b4dcb51abf406e5c9f6" :
                        event.id === 5 ? "https://z-cdn-media.chatglm.cn/files/07fc9b5d-1970-4e28-8107-e9924d4abd11_images.jpg?auth_key=1792626539-dff492d2db27487ea6fe098827bf6617-0-33aedd8c0b6ea6d4408d6f7fcd1f6bb5" :
                        "https://z-cdn-media.chatglm.cn/files/0b3bb972-2f7b-4f13-a396-61eb51af2e26_pasted_image_1760394848523.png?auth_key=1792626539-e3dd0e8fc95d41639e25092914df503e-0-e2a51d2227135405c2836df4fca8050"
                      }
                      alt={event.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                      <div className="text-center text-white">
                        <div className="text-2xl font-bold">{event.day}</div>
                        <div className="text-sm">{event.month}</div>
                      </div>
                    </div>
                    <div className="absolute top-2 right-2">
                      <Calendar className="w-5 h-5 text-white" />
                    </div>
                  </div>
                  <div className="p-4">
                    <h4 className="font-bold text-blue-900 mb-2">{event.title}</h4>
                    <p className="text-sm text-gray-600 mb-3">{event.desc}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-blue-600 font-medium">Evento escolar</span>
                      <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <ChevronRight className="w-4 h-4 text-blue-900" />
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Courses Section */}
      <section id="courses" className="py-20 px-4 bg-white fade-in-section opacity-0 transition-all duration-1000 ease-out"
             style={{ 
               opacity: visibleElements.has('courses') ? 1 : 0,
               transform: visibleElements.has('courses') ? 'translateY(0)' : 'translateY(30px)'
             }}>
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">
              Nossos Cursos e Programas
            </h2>
            <p className="text-lg text-blue-700 font-medium italic mb-4">
              "Educação com Qualidade e Compromisso"
            </p>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Educação completa da Educação Infantil ao Ensino Fundamental
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="card-clickable hover:shadow-lg transition-shadow fade-in-section opacity-0 transition-all duration-1000 ease-out delay-200 border-blue-200"
                  style={{ 
                    opacity: visibleElements.has('courses') ? 1 : 0,
                    transform: visibleElements.has('courses') ? 'translateY(0)' : 'translateY(30px)'
                  }}>
              <CardHeader>
                <div className="w-12 h-12 bg-blue-900 rounded-lg flex items-center justify-center mb-4">
                  <BookOpen className="w-6 h-6 text-white" />
                </div>
                <CardTitle className="text-lg text-blue-900">Educação Infantil</CardTitle>
                <CardDescription>2 a 5 anos</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-blue-900" />
                    Desenvolvimento integral
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-blue-900" />
                    Atividades lúdicas
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-blue-900" />
                    Estímulo à criatividade
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="card-clickable hover:shadow-lg transition-shadow fade-in-section opacity-0 transition-all duration-1000 ease-out delay-600 border-blue-200"
                  style={{ 
                    opacity: visibleElements.has('courses') ? 1 : 0,
                    transform: visibleElements.has('courses') ? 'translateY(0)' : 'translateY(30px)'
                  }}>
              <CardHeader>
                <div className="w-12 h-12 bg-blue-900 rounded-lg flex items-center justify-center mb-4">
                  <BookOpen className="w-6 h-6 text-white" />
                </div>
                <CardTitle className="text-lg text-blue-900">Ensino Fundamental I</CardTitle>
                <CardDescription>1º ao 5º ano</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-blue-900" />
                    Alfabetização sólida
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-blue-900" />
                    Base matemática
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-blue-900" />
                    Inglês desde cedo
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="card-clickable hover:shadow-lg transition-shadow fade-in-section opacity-0 transition-all duration-1000 ease-out delay-600 border-blue-200"
                  style={{ 
                    opacity: visibleElements.has('courses') ? 1 : 0,
                    transform: visibleElements.has('courses') ? 'translateY(0)' : 'translateY(30px)'
                  }}>
              <CardHeader>
                <div className="w-12 h-12 bg-blue-900 rounded-lg flex items-center justify-center mb-4">
                  <BookOpen className="w-6 h-6 text-white" />
                </div>
                <CardTitle className="text-lg text-blue-900">Ensino Fundamental II</CardTitle>
                <CardDescription>6º ao 9º ano</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-blue-900" />
                    Professores especialistas
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-blue-900" />
                    Laboratórios
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-blue-900" />
                    Preparação para ENEM
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Facilities Section */}
      <section id="facilities" className="py-20 px-4 bg-blue-50 fade-in-section opacity-0 transition-all duration-1000 ease-out"
             style={{ 
               opacity: visibleElements.has('facilities') ? 1 : 0,
               transform: visibleElements.has('facilities') ? 'translateY(0)' : 'translateY(30px)'
             }}>
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">
              Nossa Estrutura
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Instalações modernas e seguras para o melhor aprendizado
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="text-center fade-in-section opacity-0 transition-all duration-1000 ease-out delay-200 border-blue-200"
                  style={{ 
                    opacity: visibleElements.has('facilities') ? 1 : 0,
                    transform: visibleElements.has('facilities') ? 'translateY(0)' : 'translateY(30px)'
                  }}>
              <CardHeader>
                <Building className="w-12 h-12 text-blue-900 mx-auto mb-4" />
                <CardTitle className="text-blue-900">Salas de Aula Modernas</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Ambientes climatizados com tecnologia interativa e mobiliário ergonômico.
                </p>
              </CardContent>
            </Card>

            <Card className="card-clickable text-center fade-in-section opacity-0 transition-all duration-1000 ease-out delay-600 border-blue-200"
                  style={{ 
                    opacity: visibleElements.has('facilities') ? 1 : 0,
                    transform: visibleElements.has('facilities') ? 'translateY(0)' : 'translateY(30px)'
                  }}>
              <CardHeader>
                <BookOpen className="w-12 h-12 text-blue-900 mx-auto mb-4" />
                <CardTitle className="text-blue-900">Laboratórios</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Laboratórios de Ciências, Informática e Robótica equipados com tecnologia de ponta.
                </p>
              </CardContent>
            </Card>

            <Card className="card-clickable text-center fade-in-section opacity-0 transition-all duration-1000 ease-out delay-200 border-blue-200"
                  style={{ 
                    opacity: visibleElements.has('facilities') ? 1 : 0,
                    transform: visibleElements.has('facilities') ? 'translateY(0)' : 'translateY(30px)'
                  }}>
              <CardHeader>
                <Users className="w-12 h-12 text-blue-900 mx-auto mb-4" />
                <CardTitle className="text-blue-900">Áreas Esportivas</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Quadras poliesportivas, campo de futebol e playgrounds seguros.
                </p>
              </CardContent>
            </Card>

            <Card className="card-clickable text-center fade-in-section opacity-0 transition-all duration-1000 ease-out delay-200 border-blue-200"
                  style={{ 
                    opacity: visibleElements.has('facilities') ? 1 : 0,
                    transform: visibleElements.has('facilities') ? 'translateY(0)' : 'translateY(30px)'
                  }}>
              <CardHeader>
                <BookOpen className="w-12 h-12 text-blue-900 mx-auto mb-4" />
                <CardTitle className="text-blue-900">Biblioteca</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Acervo diversificado com mais de 10.000 títulos e sala de estudos.
                </p>
              </CardContent>
            </Card>

            <Card className="card-clickable text-center fade-in-section opacity-0 transition-all duration-1000 ease-out delay-200 border-blue-200"
                  style={{ 
                    opacity: visibleElements.has('facilities') ? 1 : 0,
                    transform: visibleElements.has('facilities') ? 'translateY(0)' : 'translateY(30px)'
                  }}>
              <CardHeader>
                <Building className="w-12 h-12 text-blue-900 mx-auto mb-4" />
                <CardTitle className="text-blue-900">Auditório</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Espaço para eventos, apresentações culturais e palestras educativas.
                </p>
              </CardContent>
            </Card>

            <Card className="card-clickable text-center fade-in-section opacity-0 transition-all duration-1000 ease-out delay-200 border-blue-200"
                  style={{ 
                    opacity: visibleElements.has('facilities') ? 1 : 0,
                    transform: visibleElements.has('facilities') ? 'translateY(0)' : 'translateY(30px)'
                  }}>
              <CardHeader>
                <Users className="w-12 h-12 text-blue-900 mx-auto mb-4" />
                <CardTitle className="text-blue-900">Refeitório</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Refeições balanceadas preparadas por nutricionistas com cardápio variado.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Photo Gallery */}
          <div className="mt-16">
            <h3 className="text-2xl font-bold text-blue-900 text-center mb-8">
              Conheça Nossa Estrutura
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {[
                { id: 1, title: "Salas de Aula", desc: "Ambientes modernos e climatizados", image: "https://z-cdn-media.chatglm.cn/files/f7d4bb0e-17a3-4900-9972-f0a038b4fd94_images.jpg?auth_key=1792626539-82748de9c37142ac885c0fa5ee6e8b86-0-332b3bb888664b4dcb51abf406e5c9f6" },
                { id: 2, title: "Laboratórios", desc: "Ciências e Informática", image: "https://z-cdn-media.chatglm.cn/files/07fc9b5d-1970-4e28-8107-e9924d4abd11_images.jpg?auth_key=1792626539-dff492d2db27487ea6fe098827bf6617-0-33aedd8c0b6ea6d4408d6f7fcd1f6bb5" },
                { id: 3, title: "Biblioteca", desc: "Mais de 10.000 títulos", image: "https://z-cdn-media.chatglm.cn/files/0b3bb972-2f7b-4f13-a396-61eb51af2e26_pasted_image_1760394848523.png?auth_key=1792626539-e3dd0e8fc95d41639e25092914df503e-0-e2a51d2227135405c2836df4fca8050" },
                { id: 4, title: "Quadras Esportivas", desc: "Esportes e atividades físicas", image: "https://z-cdn-media.chatglm.cn/files/6bbc815a-996e-42b1-b98d-596ac9263523_images.jpg?auth_key=1792626539-c34ab09aa22840f1af4a037152886ab8-0-04eca8abd547bfcc7cd1190474c0221c" },
                { id: 5, title: "Auditório", desc: "Eventos e apresentações", image: "https://z-cdn-media.chatglm.cn/files/f7d4bb0e-17a3-4900-9972-f0a038b4fd94_images.jpg?auth_key=1792626539-82748de9c37142ac885c0fa5ee6e8b86-0-332b3bb888664b4dcb51abf406e5c9f6" },
                { id: 6, title: "Refeitório", desc: "Nutrição balanceada", image: "https://z-cdn-media.chatglm.cn/files/07fc9b5d-1970-4e28-8107-e9924d4abd11_images.jpg?auth_key=1792626539-dff492d2db27487ea6fe098827bf6617-0-33aedd8c0b6ea6d4408d6f7fcd1f6bb5" },
                { id: 7, title: "Playground", desc: "Área de recreação segura", image: "https://z-cdn-media.chatglm.cn/files/0b3bb972-2f7b-4f13-a396-61eb51af2e26_pasted_image_1760394848523.png?auth_key=1792626539-e3dd0e8fc95d41639e25092914df503e-0-e2a51d2227135405c2836df4fca8050" },
                { id: 8, title: "Jardins", desc: "Áreas verdes e relaxamento", image: "https://z-cdn-media.chatglm.cn/files/6bbc815a-996e-42b1-b98d-596ac9263523_images.jpg?auth_key=1792626539-c34ab09aa22840f1af4a037152886ab8-0-04eca8abd547bfcc7cd1190474c0221c" }
              ].map((photo, index) => (
                <div key={photo.id} className="group relative overflow-hidden rounded-lg shadow-md hover:shadow-xl transition-all duration-300 fade-in-section opacity-0"
                     style={{ 
                       opacity: visibleElements.has('facilities') ? 1 : 0,
                       transform: visibleElements.has('facilities') ? 'translateY(0)' : 'translateY(30px)',
                       transitionDelay: `${(index + 8) * 100}ms`
                     }}>
                  <div className="aspect-square relative">
                    <img 
                      src={photo.image}
                      alt={photo.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
                      <div className="p-4 text-white">
                        <h4 className="text-sm font-bold mb-1">{photo.title}</h4>
                        <p className="text-xs opacity-90">{photo.desc}</p>
                      </div>
                    </div>
                  </div>
                  <div className="absolute inset-0 bg-blue-900/0 group-hover:bg-blue-900/20 transition-colors duration-300 flex items-center justify-center">
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <div className="bg-white text-blue-900 px-3 py-1 rounded-full text-xs font-medium">
                        Ver mais
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-4 bg-white fade-in-section opacity-0 transition-all duration-1000 ease-out"
             style={{ 
               opacity: visibleElements.has('contact') ? 1 : 0,
               transform: visibleElements.has('contact') ? 'translateY(0)' : 'translateY(30px)'
             }}>
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">
              Entre em Contato
            </h2>
            <p className="text-lg text-blue-700 font-medium italic mb-4">
              "Estamos aqui para iluminar o futuro de seu filho"
            </p>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Visite-nos ou envie uma mensagem. Teremos prazer em atendê-lo!
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <Card className="border-blue-200">
                <CardHeader>
                  <CardTitle className="text-blue-900">Informações de Contato</CardTitle>
                  <CardDescription>Estamos localizados no coração de João Pessoa</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-start gap-4">
                    <MapPin className="w-5 h-5 text-blue-900 mt-1" />
                    <div>
                      <h4 className="font-semibold text-blue-900">Endereço</h4>
                      <p className="text-gray-600">
                        Rua Benício de Oliveira Lima, 339<br />
                        Bairro: José Américo de Almeida<br />
                        João Pessoa - PB<br />
                        CEP: 58073-030
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <Phone className="w-5 h-5 text-blue-900 mt-1" />
                    <div>
                      <h4 className="font-semibold text-blue-900">Telefone</h4>
                      <p className="text-gray-600">(83) 98808-5898</p>
                      <p className="text-gray-600">(83) 98808-5898 (WhatsApp)</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <Mail className="w-5 h-5 text-blue-900 mt-1" />
                    <div>
                      <h4 className="font-semibold text-blue-900">E-mail</h4>
                      <p className="text-gray-600">contato@institutodominique.com.br</p>
                      <p className="text-gray-600">secretaria@institutodominique.com.br</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <Clock className="w-5 h-5 text-blue-900 mt-1" />
                    <div>
                      <h4 className="font-semibold text-blue-900">Horário de Funcionamento</h4>
                      <p className="text-gray-600">
                        Segunda a Sexta: 7h30 às 17h30<br />
                        Sábado: 8h às 12h<br />
                        Domingo: Fechado
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div>
              <Card className="border-blue-200">
                <CardHeader>
                  <CardTitle className="text-blue-900">Envie uma Mensagem</CardTitle>
                  <CardDescription>Fale conosco e tire suas dúvidas</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-blue-900 mb-1">
                        Nome Completo
                      </label>
                      <Input
                        id="name"
                        name="name"
                        type="text"
                        required
                        value={formData.name}
                        onChange={handleInputChange}
                        placeholder="Seu nome completo"
                        className="border-blue-200 focus:border-blue-900"
                      />
                    </div>

                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-blue-900 mb-1">
                        E-mail
                      </label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        required
                        value={formData.email}
                        onChange={handleInputChange}
                        placeholder="seu@email.com"
                        className="border-blue-200 focus:border-blue-900"
                      />
                    </div>

                    <div>
                      <label htmlFor="phone" className="block text-sm font-medium text-blue-900 mb-1">
                        Telefone
                      </label>
                      <Input
                        id="phone"
                        name="phone"
                        type="tel"
                        required
                        value={formData.phone}
                        onChange={handleInputChange}
                        placeholder="(83) 00000-0000"
                        className="border-blue-200 focus:border-blue-900"
                      />
                    </div>

                    <div>
                      <label htmlFor="message" className="block text-sm font-medium text-blue-900 mb-1">
                        Mensagem
                      </label>
                      <Textarea
                        id="message"
                        name="message"
                        required
                        value={formData.message}
                        onChange={handleInputChange}
                        placeholder="Como podemos ajudar você?"
                        rows={4}
                        className="border-blue-200 focus:border-blue-900"
                      />
                    </div>

                    <Button 
                      type="submit" 
                      className="clickable w-full bg-blue-900 hover:bg-blue-800 text-white font-medium"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                          Enviando...
                        </>
                      ) : (
                        'Enviar Mensagem'
                      )}
                    </Button>
                    
                    {/* Mensagens de feedback */}
                    {submitMessage && (
                      <div className={`mt-4 p-3 rounded-md text-sm ${
                        submitStatus === 'success' 
                          ? 'bg-green-50 text-green-800 border border-green-200' 
                          : 'bg-red-50 text-red-800 border border-red-200'
                      }`}>
                        {submitMessage}
                      </div>
                    )}
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer id="footer" className="bg-blue-900 text-white py-12 px-4 fade-in-section opacity-0 transition-all duration-1000 ease-out"
           style={{ 
             opacity: visibleElements.has('footer') ? 1 : 0,
             transform: visibleElements.has('footer') ? 'translateY(0)' : 'translateY(30px)'
           }}>
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <a href="#home" className="flex items-center space-x-2 mb-4 hover:opacity-80 transition-opacity inline-block">
                <div className="w-12 h-10 bg-white rounded-lg flex items-center justify-center p-1">
                  <div className="text-blue-900 text-center">
                    <div className="text-xs font-bold leading-none">Instituto</div>
                    <div className="text-xs font-bold leading-none">Educacional</div>
                    <div className="text-xs font-bold leading-none">Dominique</div>
                  </div>
                </div>
                <div>
                  <h3 className="font-bold">Instituto Dominique</h3>
                  <p className="text-xs text-blue-200">Desde 1989</p>
                </div>
              </a>
              <p className="text-blue-100 text-sm mb-2">
                Educação de excelência por mais de 30 anos para transformar vidas e construir um futuro melhor.
              </p>
              <p className="text-blue-200 text-xs italic">
                "O estudo é a luz da vida"
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Links Rápidos</h4>
              <ul className="space-y-2 text-sm text-blue-100">
                <li><a href="#home" className="hover:text-white transition-colors">Início</a></li>
                <li><a href="#about" className="hover:text-white transition-colors">Sobre Nós</a></li>
                <li><a href="#courses" className="hover:text-white transition-colors">Cursos</a></li>
                <li><a href="#facilities" className="hover:text-white transition-colors">Estrutura</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Cursos</h4>
              <ul className="space-y-2 text-sm text-blue-100">
                <li>Educação Infantil</li>
                <li>Ensino Fundamental I</li>
                <li>Ensino Fundamental II</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Contato</h4>
              <ul className="space-y-2 text-sm text-blue-100">
                <li className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  (83) 98808-5898
                </li>
                <li className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  contato@institutodominique.com.br
                </li>
                <li className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  José Américo de Almeida, João Pessoa - PB
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-blue-800 mt-8 pt-8 text-center text-sm text-blue-200">
            <p>&copy; 2024 Instituto Educacional Dominique. Todos os direitos reservados.</p>
            <p className="text-xs mt-2 italic">"O estudo é a luz da vida" • Desde 1989 iluminando mentes</p>
          </div>
        </div>
      </footer>
    </div>
  )
}